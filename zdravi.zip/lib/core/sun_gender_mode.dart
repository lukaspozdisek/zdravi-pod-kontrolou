enum SunGenderMode { woman, man }
